package com.retengr.test;

import java.util.List;

import org.apache.commons.logging.impl.Log4JLogger;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.retengr.model.Client;
import com.retengr.model.Compte;
import com.retengr.service.Banque;

public class BanqueTest {
	@SuppressWarnings("unused")
	private static final Log4JLogger log = new Log4JLogger("BanqueTest");
	private static ApplicationContext ctx;

	@BeforeClass
	public static void init() {
		ctx = new ClassPathXmlApplicationContext("beans.xml");
	}

	@Test
	public void testDetailClient() {
		Banque b = ctx.getBean(Banque.class);
		Assert.assertNotNull(b);

		b.transfer(1L, 2L, 10);
		
	}

	

}
