package com.retengr.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.retengr.dao.ClientDAO;
import com.retengr.model.Client;

@Component
public class ClientDAOImpl implements ClientDAO {
	
	@Autowired
	private DataSource datasource;

	public void create(Client c) {
		try {
			Connection connexion = getDatasource().getConnection();
			PreparedStatement pSt = connexion
					.prepareStatement("INSERT INTO CLIENT (ID, NOM, PRENOM) VALUES (NULL, ? , ? )");
			pSt.setString(1, c.getNom());
			pSt.setString(2, c.getPrenom());
			pSt.executeUpdate();
			pSt.close();
			connexion.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void delete(Client c) {
		try {
			Connection connexion = getDatasource().getConnection();
			PreparedStatement pSt = connexion
					.prepareStatement("DELETE FROM CLIENT WHERE ID=?");
			pSt.setLong(1, c.getId());
			pSt.executeUpdate();
			System.out.println("Client " + c.getId() + " supprim�");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Client> getClients() {
		List<Client> result = new ArrayList<Client>();

		try {
			Connection connexion = getDatasource().getConnection();

			// Extraction
			Statement St = connexion.createStatement();
			ResultSet rs = St.executeQuery("SELECT * FROM CLIENT");

			Client c;
			while (rs.next()) {
				// Mapping
				c = new Client();
				c.setId(rs.getLong("ID"));
				c.setNom(rs.getString("NOM"));
				c.setPrenom(rs.getString("PRENOM"));
				result.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;

	}

	public DataSource getDatasource() {
		return datasource;
	}

	public Client read(Long id) {
		Client result = null;
		try {
			Connection connexion = getDatasource().getConnection();

			// Extraction

			Statement St = connexion.createStatement();
			ResultSet rs = St.executeQuery("SELECT * FROM CLIENT where id="
					+ id);

			rs.next();
			result = new Client();
			result.setId(rs.getLong("ID"));
			result.setNom(rs.getString("NOM"));
			result.setPrenom(rs.getString("PRENOM"));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;

	}

	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
	}

	public void update(Client c) {
		try {
			Connection connexion = getDatasource().getConnection();
			PreparedStatement pSt = connexion
					.prepareStatement("UPDATE CLIENT SET NOM=?, PRENOM=? WHERE ID=?");
			pSt.setString(1, c.getNom());
			pSt.setString(2, c.getPrenom());
			pSt.setLong(3, c.getId());

			pSt.executeUpdate();
			System.out.println("Client " + c.getId() + " modifi�");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
