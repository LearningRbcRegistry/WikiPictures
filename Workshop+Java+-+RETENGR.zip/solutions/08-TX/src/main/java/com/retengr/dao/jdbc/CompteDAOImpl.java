package com.retengr.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;

import com.retengr.dao.CompteDAO;
import com.retengr.model.Compte;

@Component
public class CompteDAOImpl implements CompteDAO {
	
	@Autowired
	private DataSource datasource;

	
	private static String SQL_UPDATE = "UPDATE COMPTE c SET c.SOLDE=:solde, c.NUMERO=:numero, c.DESCRIPTION=:description WHERE c.id=:id";

	private Map<String, Object> convertCompteToMap(Compte c) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("id", c.getId());
		parameters.put("numero", c.getNumero());
		parameters.put("solde", c.getSolde());
		parameters.put("description", c.getLabel());

		return parameters;

	}
	
	
	
	public void create(Compte c) {
		// TODO Auto-generated method stub

	}

	public void delete(Compte c) {
		// TODO Auto-generated method stub

	}

	public List<Compte> getCompteDuClient(Long id) {
		List<Compte> result = new ArrayList<Compte>();

		try {
			Connection connexion = getDatasource().getConnection();

			PreparedStatement pSt = connexion
					.prepareStatement("SELECT * FROM COMPTE WHERE FK_CLIENT=?");
			pSt.setLong(1, id);

			ResultSet rs = pSt.executeQuery();
			while (rs.next()) {
				Compte c = new Compte();
				c.setId(rs.getLong("ID"));
				c.setNumero(rs.getString("ID"));

				c.setSolde(rs.getLong("SOLDE"));
				c.setLabel(rs.getString("DESCRIPTION"));

				result.add(c);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public DataSource getDatasource() {
		return datasource;
	}

	public Compte read(Long id) {
		Compte result = null;
		try {
			
			Connection connexion = getDatasource().getConnection();

			PreparedStatement pSt = connexion
					.prepareStatement("SELECT * FROM COMPTE WHERE ID=?");
			pSt.setLong(1, id);
			ResultSet rs = pSt.executeQuery();
			rs.next();
			result = new Compte();
			result.setId(id);
			result.setNumero(rs.getString("NUMERO"));
			result.setSolde(rs.getLong("SOLDE"));
			result.setLabel(rs.getString("DESCRIPTION"));

			// On ne mappe pas la relation avec le client => Limitation de
			// l'exemple

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
	}
	public void update2(Compte c) {
		throw new RuntimeException();
	}
	
	/*public void update(Compte c) {
		try {
			NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(
					datasource);
			template.update(SQL_UPDATE, convertCompteToMap(c));
		} catch (Exception e) {
			//throw new TechnicalError();
			throw new RuntimeException();
		}
	}*/
	
	public void update(Compte c) {
		try {
			
			Connection connexion = DataSourceUtils.getConnection(getDatasource());
			//Connection connexion = getDatasource().getConnection();


			PreparedStatement pSt;

			pSt = connexion
					.prepareStatement(" UPDATE COMPTE SET NUMERO = ? , SOLDE = ? WHERE ID=?");
			pSt.setString(1, c.getNumero());
			pSt.setDouble(2, c.getSolde());
			pSt.setLong(3, c.getId());
			pSt.executeUpdate();
			System.out.println("Compte modifié");
		} catch (SQLException e) {
			throw new RuntimeException();
		}

	}

}
