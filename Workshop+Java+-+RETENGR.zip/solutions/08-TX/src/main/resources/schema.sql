DROP TABLE COMPTE if exists;
DROP TABLE CLIENT  if exists;


/* Creating table CLIENT */
CREATE TABLE CLIENT (
    ID integer identity PRIMARY KEY ,
    NOM varchar(40) not null,
    PRENOM varchar(40) not null,
	UNIQUE (ID)
);

/*  Creating table COMPTE */
CREATE TABLE COMPTE (
    ID integer identity PRIMARY KEY ,
    NUMERO int not null,
    SOLDE integer,
	FK_CLIENT integer,
	DESCRIPTION varchar,
    FOREIGN KEY (FK_CLIENT) REFERENCES CLIENT,
    UNIQUE (ID)
);