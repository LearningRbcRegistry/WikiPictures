package com.retengr.dao;

import java.util.List;

import com.retengr.model.Compte;

public interface CompteDAO {

	public abstract void create(Compte c);

	public abstract void delete(Compte c);

	public abstract List<Compte> getCompteDuClient(Long id);

	public abstract Compte read(Long id);

	public abstract void update(Compte c);

}