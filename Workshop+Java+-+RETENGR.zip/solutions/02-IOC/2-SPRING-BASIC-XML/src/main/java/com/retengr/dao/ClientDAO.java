package com.retengr.dao;

import java.util.List;

import com.retengr.model.Client;

public interface ClientDAO {

	public abstract void create(Client c);

	public abstract void delete(Client c);

	public abstract List<Client> getClients();

	public abstract Client read(Long id);

	public abstract void update(Client c);

}