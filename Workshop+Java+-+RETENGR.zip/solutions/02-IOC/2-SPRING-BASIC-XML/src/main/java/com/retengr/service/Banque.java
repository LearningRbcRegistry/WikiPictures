package com.retengr.service;

import java.util.List;

import com.retengr.model.Client;
import com.retengr.model.Compte;

public interface Banque {

	public abstract Client detailClient(Long id);

	public abstract List<Client> listeClients();

	public abstract List<Compte> listeComptes(Long id);

	public abstract void transfer(Long id1, Long id2, double m);

}