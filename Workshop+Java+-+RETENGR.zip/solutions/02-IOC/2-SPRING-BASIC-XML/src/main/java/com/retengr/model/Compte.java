package com.retengr.model;

public class Compte {
	private Long id;
	private String label;
	private String numero;
	private double solde;

	public void credit(double m) {
		solde = solde + m;
	}

	public void debit(double m) {
		solde = solde - m;
	}

	public Long getId() {
		return id;
	}

	public String getLabel() {
		return label;
	}

	public String getNumero() {
		return numero;
	}

	public double getSolde() {
		return solde;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public void setSolde(double solde) {
		this.solde = solde;
	}
}
