package com.retengr.dao.mock;

import java.util.ArrayList;
import java.util.List;


import com.retengr.dao.ClientDAO;
import com.retengr.model.Client;
import javax.inject.Named;

@Named("clientDAO")
public class ClientDAOImpl implements ClientDAO {
	public void create(Client c) {
		System.out.println("Creation d'un Client");
	}

	public void delete(Client c) {
		System.out.println("Suprresion d'un Client");
	}

	public List<Client> getClients() {
            return new ArrayList<Client>();
	}

	public Client read(Long id) {
		Client c = new Client();
		c.setId(id);
		return c;
	}

	public void update(Client c) {
		System.out.println("update d'un Client");
	}

}
