package com.retengr.dao.mock;

import java.util.ArrayList;
import java.util.List;


import com.retengr.dao.CompteDAO;
import com.retengr.model.Compte;
import javax.inject.Named;

@Named("compteDAO")
public class CompteDAOImpl implements CompteDAO {
	public void create(Compte c) {
		System.out.println("Creation d'un compte");
	}

	public void delete(Compte c) {
		System.out.println("Suprresion d'un compte");
	}

	public List<Compte> getCompteDuClient(Long id) {
            System.out.println("geCompteDuClient:"+id);
            return new ArrayList<Compte>();
	}

	public Compte read(Long id) {
		Compte c = new Compte();
		c.setId(id);
		return c;
	}

	public void update(Compte c) {
		System.out.println("update d'un compte");
	}

}
