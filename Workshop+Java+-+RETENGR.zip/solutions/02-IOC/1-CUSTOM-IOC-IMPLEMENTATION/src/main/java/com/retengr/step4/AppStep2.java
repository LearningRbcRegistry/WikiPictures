package com.retengr.step4;



/**
 * Hello world!
 *
 */
public class AppStep2 
{
    public static void main( String[] args )
    {
        A a = (A)MyBeanFactory.get("a");
        a.methodFromA();
    }
}
