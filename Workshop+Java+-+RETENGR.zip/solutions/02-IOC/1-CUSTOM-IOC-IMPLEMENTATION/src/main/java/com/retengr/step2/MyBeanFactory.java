/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.retengr.step2;

/**
 *
 * @author denispeyrusaubes
 */
public class MyBeanFactory {
    public static A getA() {
        return new A();
    }
    public static B getB() {
        return new B();
    }
    
    
    
}
