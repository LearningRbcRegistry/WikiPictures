/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retengr.step4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;

/**
 *
 * @author denispeyrusaubes
 */
public class MyBeanFactory {

    private final static Map<String, Object> conf = new HashMap<String, Object>();

    static {
        parsePackage();

    }

    public static Object get(String key) {
        return conf.get(key);
    }

    
    private static void parsePackage() {
        
    }
    
    

}
