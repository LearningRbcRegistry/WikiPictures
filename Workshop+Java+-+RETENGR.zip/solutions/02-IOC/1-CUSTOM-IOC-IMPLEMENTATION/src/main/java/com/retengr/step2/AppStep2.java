package com.retengr.step2;


/**
 * Hello world!
 *
 */
public class AppStep2 
{
    public static void main( String[] args )
    {
        A a = MyBeanFactory.getA();
        a.methodFromA();
    }
}
