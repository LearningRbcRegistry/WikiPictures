/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retengr.step3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;

/**
 *
 * @author denispeyrusaubes
 */
public class MyBeanFactory {

    private final static Map<String, Object> conf = new HashMap<String, Object>();

    static {
        try {
            ResourceBundle bundle = ResourceBundle.getBundle("conf");
            Iterator<String> keys = bundle.keySet().iterator();
            while (keys.hasNext()) {
                String currentKey = keys.next();
                String className = bundle.getString(currentKey);
                Class c = Class.forName(className + ".class");
                conf.put(currentKey, c.newInstance());
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

    }

    public static Object get(String key) {
        return conf.get(key);
    }


}
