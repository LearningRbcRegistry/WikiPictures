/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.retengr.step1;

/**
 *
 * @author denispeyrusaubes
 */
public class A {
    
    private B b;
    
    public A() {
        System.out.println("Construction de A");
        b = new B();
        System.out.println("A est construit");
    }
    
    public void methodFromA(){
        System.out.println("Methode de A");
        b.methodFromB();
        System.out.println("Fin méthode de A");

    }
}
