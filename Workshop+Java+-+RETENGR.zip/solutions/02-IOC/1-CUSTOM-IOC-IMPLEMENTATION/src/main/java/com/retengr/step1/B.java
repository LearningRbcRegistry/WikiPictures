/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.retengr.step1;

/**
 *
 * @author denispeyrusaubes
 */
public class B {
    
    public B() {
        System.out.println("-> Construction de B");
    }
    
    public void methodFromB() {
        System.out.println("-> Methode de B");
    }
}
