package com.retengr.step1;

/**
 * Hello world!
 *
 */
public class AppStep1 
{
    public static void main( String[] args )
    {
        A a = new A();
        a.methodFromA();
    }
}
