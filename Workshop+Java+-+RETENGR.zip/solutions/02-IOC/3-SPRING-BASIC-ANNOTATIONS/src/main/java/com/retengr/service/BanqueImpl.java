package com.retengr.service;

import java.util.List;

import com.retengr.dao.ClientDAO;
import com.retengr.dao.CompteDAO;
import com.retengr.model.Client;
import com.retengr.model.Compte;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class BanqueImpl implements Banque {

    private ClientDAO clientDAO;

    private CompteDAO compteDAO;

    /*
     * (non-Javadoc)
     * 
     * @see com.valtech.service.Banque#detailClient(java.lang.Long)
     */
    public Client detailClient(Long id) {
        return clientDAO.read(id);
    }

    public ClientDAO getClientDAO() {
        return clientDAO;
    }

    public CompteDAO getCompteDAO() {
        return compteDAO;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.valtech.service.Banque#listeClients()
     */
    public List<Client> listeClients() {
        return clientDAO.getClients();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.valtech.service.Banque#listeComptes(java.lang.Long)
     */
    public List<Compte> listeComptes(Long id) {
        return compteDAO.getCompteDuClient(id);
    }

    @Autowired
    public void setClientDAO(ClientDAO clientDAO) {
        this.clientDAO = clientDAO;
    }

    @Autowired  
    public void setCompteDAO(CompteDAO compteDAO) {
        this.compteDAO = compteDAO;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.valtech.service.Banque#transfer(java.lang.Long, java.lang.Long,
     *      double)
     */
    public void transfer(Long id1, Long id2, double m) {
        Compte c1 = compteDAO.read(id1);
        Compte c2 = compteDAO.read(id2);
        c1.debit(m);
        c2.credit(m);
        compteDAO.update(c1);
        compteDAO.update(c2);

    }

}
