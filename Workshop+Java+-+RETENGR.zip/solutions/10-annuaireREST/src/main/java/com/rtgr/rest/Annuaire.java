package com.rtgr.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/annuaire")
public class Annuaire {
	private Map<String, Personne> annuaire = new HashMap<String, Personne>();

	public Annuaire() {
		Personne p1 = new Personne("Durand", "Paul");
		Personne p2 = new Personne("Dupond", "Pierre");
		Personne p3 = new Personne("Durand", "Jacques");
		annuaire.put(p1.getPrenom(), p1);
		annuaire.put(p2.getPrenom(), p2);
		annuaire.put(p3.getPrenom(), p3);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Personne> list() {
		return new ArrayList<Personne>(annuaire.values());
	}

	@GET
	@Path("/{prenom}")
	@Produces(MediaType.APPLICATION_JSON)
	public Personne find(@PathParam("prenom")  String prenom) {		
		return annuaire.get(prenom);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response add(Personne p) {
		annuaire.put(p.getPrenom(), p);
		return Response.status(201).entity(p).build();

	}

}
