/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.retengr;

import com.retengr.dao.ClientDAO;
import com.retengr.model.Client;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author denispeyrusaubes
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/beans-test.xml"})
public class TestWithSpring {
    
    @Inject private ClientDAO clientDAO;
    
    @Test
    public void allClients() {
    
        List<Client> clients = null;
        try {
            clients = clientDAO.all();
        } catch (SQLException ex) {
            fail();
            Logger.getLogger(TestWithSpring.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        if (null != clients) assertEquals(clients.size(), 3);
    }
    
}
