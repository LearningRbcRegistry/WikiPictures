package com.retengr.dao.jdbc;


import com.retengr.dao.ClientDAO;
import com.retengr.model.Client;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import javax.inject.Named;
import javax.sql.DataSource;

@Named("clientDAO")
public class ClientDAOImpl implements ClientDAO {

    @Inject private DataSource dataSource;

    public List<Client> all()  throws SQLException {
        Connection con;
        con = dataSource.getConnection();
        Statement st = con.createStatement();
        
        List<Client> clients = new ArrayList<Client>();
        
        ResultSet rs = st.executeQuery("select * from client");
        Client c;
        while (rs.next()) {
            c = new Client();
            c.setNom(rs.getString("nom"));
            c.setPrenom(rs.getString("prenom"));
            clients.add(c);
        }
        return clients;
        
    }

  
}
