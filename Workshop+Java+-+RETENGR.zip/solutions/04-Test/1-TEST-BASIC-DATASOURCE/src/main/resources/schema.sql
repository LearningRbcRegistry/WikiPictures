CREATE TABLE client (
  id   INTEGER PRIMARY KEY,
  nom VARCHAR(30),
  prenom  VARCHAR(50)
);



