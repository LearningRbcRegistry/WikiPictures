INSERT INTO client VALUES (1, 'Dupond', 'Henri');
INSERT INTO client VALUES (2, 'Lafenetre', 'Laurent');
INSERT INTO client VALUES (3, 'Durand', 'Serge');