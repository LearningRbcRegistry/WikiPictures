DROP TABLE COMPTE if exists;
DROP TABLE CLIENT  if exists;
DROP TABLE AUDIT_LOG  if exists;
DROP SEQUENCE hibernate_sequence  if exists;

create sequence hibernate_sequence start with 1 increment by 1
create table audit_log (id bigint not null, user_id varchar(255), description varchar(255), date date, duration integer not null, primary key (id))
create table client (id bigint not null, nom varchar(255), prenom varchar(255), primary key (id))
create table compte (id bigint not null, description varchar(255), numero varchar(255), solde double not null, primary key (id))
