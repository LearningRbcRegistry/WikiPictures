package com.retengr.service;

public interface Audit {
	public void log(String msg);
}
