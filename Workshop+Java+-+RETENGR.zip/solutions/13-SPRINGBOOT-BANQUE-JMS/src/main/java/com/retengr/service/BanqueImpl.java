package com.retengr.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.retengr.model.Compte;

@Service
public class BanqueImpl implements Banque {
	@PersistenceContext
	private EntityManager em;

	private boolean onlyPositive;

	@Autowired
	Audit audit;

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class) // TechnicalError.class)
	public List<Compte> comptes() {
		List<Compte> result = null;
		if (isOnlyPositive()) {
			audit.log("Recuperation de tous les comptes Compte positifs");
			result = (List<Compte>) em.createQuery("from Compte c where c.solde > 0").getResultList();
		} else {
			audit.log("Recuperation de tous les comptes");
			result = (List<Compte>) em.createQuery("from Compte").getResultList();
		}

		return result;
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class) // TechnicalError.class)
	public void transfer(Long id1, Long id2, double m) {
		Compte c1 = em.find(Compte.class, id1);
		Compte c2 = em.find(Compte.class, id2);
		c1.debit(m);
		c2.credit(m);
	}

	public boolean isOnlyPositive() {
		return onlyPositive;
	}

	public void setOnlyPositive(boolean onlyPositive) {
		this.onlyPositive = onlyPositive;
	}

}
