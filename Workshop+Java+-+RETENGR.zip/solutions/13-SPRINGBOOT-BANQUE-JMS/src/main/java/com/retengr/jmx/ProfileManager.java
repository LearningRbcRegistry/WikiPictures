package com.retengr.jmx;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.retengr.service.Audit;
import com.retengr.service.Banque;

@Component
@ManagedResource(objectName = "com.retengr:type=rbcprofile", description = "RBC Profile Bean")
public class ProfileManager implements ProfileManagerMBean {

	@Autowired
	Banque banque;

	@Autowired
	Audit audit;

	@Override
	public boolean isOnlyPositive() {
		return banque.isOnlyPositive();
	}

	@ManagedAttribute(description = "Autorisation pour voir les comptes débiteurs")
	public void setOnlyPositive(boolean b) {
		audit.log("AUDIT-Changement droit acces:" + b);
		banque.setOnlyPositive(b);
	}

}
