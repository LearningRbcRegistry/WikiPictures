package com.retengr.jms;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.retengr.model.AuditLog;

@Component
public class LogViewer {

	@PersistenceContext
	EntityManager em;
	
	
	@JmsListener(destination = "rbc.audit")
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)
	public void displayMessage(String msg) {
		AuditLog log = new AuditLog();
		log.setDate(new Date());
		log.setDescription(msg);
		log.setDuration(0);
		log.setUserId("1");
		em.persist(log);
		
	}

}