package com.retengr.service;

import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
public class AuditImpl implements Audit{
	
	@Autowired
	private JmsMessagingTemplate jmsTemplate;

	@Autowired
	private Queue queue;

	
	public void log(String msg) {
		System.out.println("sending message");
		this.jmsTemplate.convertAndSend(this.queue, msg);
	}

}
