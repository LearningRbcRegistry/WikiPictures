package com.retengr.jmx;

public interface ProfileManagerMBean {
	public boolean isOnlyPositive();
	public void setOnlyPositive(boolean b);

}
