/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retengr.controller;

import com.retengr.modele.Client;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author denispeyrusaubes
 */
@Controller
public class ClientController {

    @RequestMapping(value = "/creationClient", method = RequestMethod.GET)
    public String showForm(Map<String, Object> model) {
        model.put("client", new Client());
        return "creationClient";
    }

    @RequestMapping(value = "/creationClient", method = RequestMethod.POST)
    public ModelAndView createClient(@Valid @ModelAttribute("client") Client client,
            BindingResult result) {

        String pageToShow = "confirmation";

        if (result.hasErrors()) {
            pageToShow = "creationClient";
        }
        ModelAndView mv = new ModelAndView(pageToShow);
        mv.addObject("status", client.getNom() + " a ete rajouté !");
        return mv;
    }

 
    
    @Secured("ROLE_BANQUIER")
    public List<Client> getAllClients() {
        // ...
    }

}
