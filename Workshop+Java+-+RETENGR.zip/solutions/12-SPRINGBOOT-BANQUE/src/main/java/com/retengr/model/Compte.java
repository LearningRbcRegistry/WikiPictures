package com.retengr.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Compte {
	@Id
	private Long id;
	private String description;
	private String numero;
	private double solde;

	public void credit(double m) {
		solde = solde + m;
	}

	public void debit(double m) {
		solde = solde - m;
	}

	public Long getId() {
		return id;
	}



	public String getNumero() {
		return numero;
	}

	public double getSolde() {
		return solde;
	}

	public void setId(Long id) {
		this.id = id;
	}



	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public void setSolde(double solde) {
		this.solde = solde;
	}
}
