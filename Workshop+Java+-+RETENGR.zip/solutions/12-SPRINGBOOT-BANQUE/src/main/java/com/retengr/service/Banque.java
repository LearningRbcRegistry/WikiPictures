package com.retengr.service;

import java.util.List;

import com.retengr.model.Compte;

public interface Banque {
    public List<Compte> comptes();
	public abstract void transfer(Long id1, Long id2, double m);
}