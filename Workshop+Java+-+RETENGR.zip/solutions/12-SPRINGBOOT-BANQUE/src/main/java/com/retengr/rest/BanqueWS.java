package com.retengr.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.retengr.model.Compte;
import com.retengr.service.Banque;

@RestController
public class BanqueWS {

	@RequestMapping("/")
	String home() {
		return "Hello World !";
	}

	
	@Autowired
	Banque banque;

	
	@RequestMapping("/comptes")
	List<Compte> tousLesComptes() {
		return banque.comptes();
	}

	
	@RequestMapping(method = RequestMethod.GET, value = "/transfer/{id1}/{id2}/{montant}")
	ResponseEntity<?> virement(@PathVariable Long id1,@PathVariable Long id2,@PathVariable int montant) {
		System.out.println("virement:"+id1+"/"+id2+"/"+montant);
		banque.transfer(id1, id2, montant);
		return ResponseEntity.ok().build();
	}
	

}
