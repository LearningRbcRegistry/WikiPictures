package com.retengr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	/*@Bean
	public DataSource customDataSource() {
		System.out.println("xxxxxxxxxxxxxxxxxxxxxxx");
		return DataSourceBuilder.create().url("jdbc:hsqldb:hsql://localhost/DB")
				.driverClassName("org.hsqldb.jdbcDriver").username("sa").password("").build();
	}*/
	/*
	 * @Bean public CommandLineRunner commandLineRunner(ApplicationContext ctx)
	 * { return args -> {
	 * 
	 * 
	 * String[] beanNames = ctx.getBeanDefinitionNames();
	 * System.out.println("Spring boot a crée "+beanNames.length+" beans:\n");
	 * 
	 * Arrays.sort(beanNames); for (String beanName : beanNames) {
	 * System.out.println(beanName); }
	 * 
	 * };
	 * 
	 * }
	 */
}
