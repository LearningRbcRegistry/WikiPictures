/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retengr.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.retengr.modele.Client;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author denispeyrusaubes
 */
@Controller
public class RestClientController {

    @RequestMapping(value = "/client/{id}", method = RequestMethod.GET)
    public @ResponseBody
    String findClient(@PathVariable Long id) throws JsonProcessingException {
        Client c = lookForClientInDB(id);
        String json = new ObjectMapper().writeValueAsString(c);
        return json;
    }

    @RequestMapping(value = "/client/{id}", method = RequestMethod.DELETE)
    public @ResponseBody
    String removeClient(@PathVariable Long id) throws JsonProcessingException {
        System.out.println("Suppression du client  " + id);
        return "{'result':'1'}";
    }

    @RequestMapping(value = "/client", method = RequestMethod.PUT, consumes = {"application/json"})
    public @ResponseBody
    String addClient(@RequestBody Client client) throws JsonProcessingException {
        System.out.println("Creation du client  " + client.getNom() + client.getPrenom());
        return "{'result':'1'}";
    }

    @RequestMapping(value = "/client", method = RequestMethod.GET)
    public @ResponseBody
    String findAll() throws JsonProcessingException {
        List<Client> result = new ArrayList<Client>();

        for (int i = 0; i < 10; i++) {
            Client c = new Client();
            c.setNom("Nom" + i);
            c.setPrenom("Prenom" + i);
            result.add(c);
        }

        String json = new ObjectMapper().writeValueAsString(result);
        return json;
    }

    private Client lookForClientInDB(Long id) {
        Client c = new Client();
        c.setNom("Papin");
        c.setPrenom("Denis");
        return c;
    }
}
