package com.rtgr.jmxsimple;

public class TmpFile implements TmpFileMBean {
	private int click;
	
	public String getFolderName() {
		// TODO Auto-generated method stub
		return "/tmp"+click;
	}

	public void clean() {
		// Suppose to clean folder...
		// Just increment click 
		click++;
	}
}
