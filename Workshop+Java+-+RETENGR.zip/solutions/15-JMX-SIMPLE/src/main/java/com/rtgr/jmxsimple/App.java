package com.rtgr.jmxsimple;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;

public class App 
{
    public static void main( String[] args ) throws Exception {
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer(); 
        ObjectName name = new ObjectName("com.retengr:type=TmpFile"); 
        TmpFile mbean = new TmpFile(); 
        mbs.registerMBean(mbean, name); 
        System.out.println("MBean Started");
        Thread.sleep(Long.MAX_VALUE); 
    }
}
