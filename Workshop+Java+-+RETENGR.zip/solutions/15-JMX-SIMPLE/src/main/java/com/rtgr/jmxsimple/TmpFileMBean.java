package com.rtgr.jmxsimple;

public interface TmpFileMBean {
	 
	  // Propriete read-only
	  public String getFolderName(); 

	  // Opération
	  public void clean();
}
