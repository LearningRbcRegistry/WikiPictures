package com.retengr.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.retengr.model.Client;

public class Main {
	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		EntityManagerFactory emf = ctx.getBean(EntityManagerFactory.class);

		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();

		Client c1 = entityManager.find(Client.class, 11L);
		Client c2 = entityManager.find(Client.class, 11L);
		c1.setNom("fdjsklfjls");
		
		List<Client> clients =(List<Client> )entityManager.createQuery("select c from Client c where c.id=11").getResultList(); 
		List<Client> clients2 =(List<Client> )entityManager.createQuery("select c from Client c where c.id=11").getResultList(); 
		
		Client c3 = clients.get(0);
		Client c4 = clients2.get(0);
		
		if (c2 == c3 ) System.out.println("EGAUX");
		
		
	
		
		entityManager.getTransaction().commit();
		entityManager.close();

	}
}
