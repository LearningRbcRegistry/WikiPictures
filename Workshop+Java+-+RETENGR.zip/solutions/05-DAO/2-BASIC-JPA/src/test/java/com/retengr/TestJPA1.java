/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retengr;

import com.retengr.model.Client;
import javax.inject.Inject;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author denispeyrusaubes
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/beans.xml"})
public class TestJPA1 {
    
    @Inject
    private EntityManagerFactory entityManagerFactory;
    
    @Test
    public void create() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        
        Client c = new Client(10L, "De Vinci", "Leonard");
        
        entityManager.persist(c);
        
        entityManager.getTransaction().commit();
        entityManager.close();
        
        Assert.assertEquals(4, numberOfClients());
        
    }
    
    @Test
    public void find() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        
        Client c = entityManager.find(Client.class, 2L);
        
        entityManager.getTransaction().commit();
        entityManager.close();
        Assert.assertEquals("Lafenetre", c.getNom());
        Assert.assertEquals("Laurent", c.getPrenom());
        
    }
    
    @Test
    public void delete() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        
        Client c = entityManager.find(Client.class, 1L);
        entityManager.remove(c);
        
        entityManager.getTransaction().commit();
        entityManager.close();
        Assert.assertEquals("Dupond", c.getNom());
        Assert.assertEquals("Henri", c.getPrenom());
        
    }
    
    private int numberOfClients() {
        int result = 0;
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        
        Long val = (Long) entityManager.createQuery("select count(c) from Client c").getSingleResult();
        result = val.intValue();
        
        entityManager.getTransaction().commit();
        entityManager.close();
        return result;
    }
}
