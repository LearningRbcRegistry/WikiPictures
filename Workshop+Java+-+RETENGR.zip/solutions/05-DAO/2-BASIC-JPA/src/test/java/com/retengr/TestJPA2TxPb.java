/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retengr;

import com.retengr.model.Client;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author denispeyrusaubes
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/beans.xml"})
public class TestJPA2TxPb {

    @PersistenceContext(name = "RetengrPU")
    private EntityManager entityManager;

    @Test(expected = IllegalStateException.class)
    public void create() {
        try {
        entityManager.getTransaction().begin();

        Client c = new Client(10L, "De Vinci", "Leonard");

        entityManager.persist(c);

        entityManager.getTransaction().commit();
        entityManager.close();

        Assert.assertEquals(4, numberOfClients());
        } catch (IllegalStateException e) {
            e.printStackTrace();
            throw e;
        }
    }

    private int numberOfClients() {
        int result = 0;
        entityManager.getTransaction().begin();

        Long val = (Long) entityManager.createQuery("select count(c) from Client c").getSingleResult();
        result = val.intValue();

        entityManager.getTransaction().commit();
        entityManager.close();
        return result;
    }
}
