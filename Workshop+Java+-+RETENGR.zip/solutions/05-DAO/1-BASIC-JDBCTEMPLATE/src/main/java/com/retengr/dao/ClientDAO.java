package com.retengr.dao;

import com.retengr.model.Client;
import java.sql.SQLException;
import java.util.List;

public interface ClientDAO {

	   List<Client> all() throws SQLException ;
           int numberOfClients()  throws SQLException ;
           Client getClient(Long id) throws SQLException ;
}