package com.retengr.dao.jdbc;

import com.retengr.dao.ClientDAO;
import com.retengr.model.Client;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.inject.Inject;

import javax.inject.Named;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@Named("clientDAO")
public class ClientDAOImpl implements ClientDAO {

    private JdbcTemplate jdbcTemplate;
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    
    @Autowired
    public ClientDAOImpl(DataSource ds) {
        this.jdbcTemplate = new JdbcTemplate(ds);        
        this.namedJdbcTemplate = new NamedParameterJdbcTemplate(ds);        
    }
    
    public List<Client> all() throws SQLException {

        List<Client> clients = this.jdbcTemplate.query(
                "select nom, prenom from client",
                new RowMapper<Client>() {
                    public Client mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Client client = new Client();
                        client.setNom(rs.getString("nom"));
                        client.setPrenom(rs.getString("prenom"));
                        return client;
                    }
                });

        return clients;

    }

    public int numberOfClients() throws SQLException {
        int rowCount = this.jdbcTemplate.queryForObject(
                "select count(*) from client", Integer.class);

        return rowCount;
    }

    public Client getClient(Long id) throws SQLException {
        Client result = null;
      
        String query = "select nom, prenom from client where id=:id";
        Map<String,Object> params = new HashMap<String,Object>();
        params.put("id",id);
        
        result = this.namedJdbcTemplate.queryForObject(
                query , params,
                new RowMapper<Client>() {
                    public Client mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Client client = new Client();
                        client.setNom(rs.getString("nom"));
                        client.setPrenom(rs.getString("prenom"));
                        return client;
                    }
                });
        
        return result;
    }

}
