package com.retengr.dao.mock;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.stereotype.Component;

import com.retengr.dao.ClientDAO;
import com.retengr.model.Client;

@Component
public class ClientDAOImpl implements ClientDAO {

    public void pause() {
        double duration = 1000*Math.random() / 2+0.3;
        //System.out.println("Sleeping " + duration + "ms");
        try {
            Thread.sleep((long) duration);
        } catch (InterruptedException ex) {
            Logger.getLogger(ClientDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void create(Client c) {
        System.out.println("Creation d'un Client");
        pause();
    }

    public void delete(Client c) {
        System.out.println("Suprresion d'un Client");
    }

    public List<Client> getClients() {
        pause();
        return new ArrayList<Client>();
    }

    public Client read(Long id) {
        pause();
        Client c = new Client();
        c.setId(id);
        return c;
    }

    public void update(Client c) {
        pause();
        System.out.println("update d'un Client");
    }

}
