/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.retengr.aspect;

import java.util.Arrays;
import javax.inject.Named;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

/**
 *
 * @author denispeyrusaubes
 */
@Aspect 
@Named("loggerAspect")
public class Logger {

    @Before("execution(* *..servicelayer.*(..))")
    public void logBefore() {
        System.out.println("Avant exécution");
    }

    @Around("execution(* *..dao.*.*(..))")
    public Object logBeforeAndAfter(ProceedingJoinPoint call) throws Throwable {
        Object result = null;
        System.out.println("Début");
        result = call.proceed();
        System.out.println("Fin");
            //		System.out
//				.println("Kind : "
//						+ (call.getKind() != null ? call.getKind().getBytes()
//								: "null"));
//		System.out
//				.println("Args"
//						+ (call.getArgs() != null ? call.getArgs().toString()
//								: "null"));
//		System.out
//				.println("Source"
//						+ (call.getSourceLocation() != null
//								&& call.getSourceLocation().getFileName() != null ? call
//								.getSourceLocation().getFileName() : "null"));
//		System.out
//				.println("StaticPart"
//						+ (call.getStaticPart() != null
//								&& call.getStaticPart().getSignature() != null
//								&& call.getStaticPart().getSignature()
//										.getName() != null ? call
//								.getStaticPart().getSignature().getName()
//								: "null"));
//		System.out.println("Target"
//				+ (call.getTarget() != null ? call.getTarget().toString()
//						: "null"));

        return result;
    }

    @AfterThrowing(pointcut = "execution(* *..dao.*.*(..))", throwing = "ex")
    public void afterThrow(JoinPoint joinPoint, Exception ex) {
        Signature signature = joinPoint.getSignature();
        String methodName = signature.getName();
        String arguments = Arrays.toString(joinPoint.getArgs());
        System.out.println("AFTER THROWING -- Une erreur de valeur c'est produit: "
                + methodName + " arguments " + arguments);
    }
}
