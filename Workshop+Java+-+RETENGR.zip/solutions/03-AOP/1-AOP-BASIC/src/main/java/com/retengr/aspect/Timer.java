package com.retengr.aspect;

import java.util.Arrays;

import javax.inject.Named;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

//@Aspect 
@Named("timerAspect")
public class Timer {

	@AfterThrowing(pointcut = "execution(* *..dao.*.*(..))", throwing = "ex")
	public void afterThrow(JoinPoint joinPoint, Exception ex) {
		Signature signature = joinPoint.getSignature();
		String methodName = signature.getName();
		String arguments = Arrays.toString(joinPoint.getArgs());
		System.out.println("AFTER THROWING -- Une erreur de valeur c'est produit: "
						+ methodName + " arguments " + arguments);
	}

	@Around("execution(* *..dao.*.*(..))")
	public Object timer(ProceedingJoinPoint call) throws Throwable {
		Object result = null;
                System.out.println("----> Aspect starts timer");
		long before = System.nanoTime();
		result = call.proceed();

		long after = System.nanoTime();
		long duration = after - before;
		String nomMethode = call.getSignature().getDeclaringTypeName() + "/"
				+ call.getSignature().getName();
		System.out.println("----> Aspect stops timer");

                System.out.println("----> Result : " + nomMethode + ":" + (duration / 1000000) + " ms");
//		System.out
//				.println("Kind : "
//						+ (call.getKind() != null ? call.getKind().getBytes()
//								: "null"));
//		System.out
//				.println("Args"
//						+ (call.getArgs() != null ? call.getArgs().toString()
//								: "null"));
//		System.out
//				.println("Source"
//						+ (call.getSourceLocation() != null
//								&& call.getSourceLocation().getFileName() != null ? call
//								.getSourceLocation().getFileName() : "null"));
//		System.out
//				.println("StaticPart"
//						+ (call.getStaticPart() != null
//								&& call.getStaticPart().getSignature() != null
//								&& call.getStaticPart().getSignature()
//										.getName() != null ? call
//								.getStaticPart().getSignature().getName()
//								: "null"));
//		System.out.println("Target"
//				+ (call.getTarget() != null ? call.getTarget().toString()
//						: "null"));
		return result;
	}

}
