package com.retengr.service;

public interface Banque {

	public abstract void transfer(Long id1, Long id2, double m);

}