package com.retengr.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.retengr.dao.CompteDAO;
import com.retengr.model.Compte;


@Service
public class BanqueImpl implements Banque {


    private CompteDAO compteDAO;

  
    public CompteDAO getCompteDAO() {
        return compteDAO;
    }

   
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class)//TechnicalError.class)
    public void transfer(Long id1, Long id2, double m) {
        Compte c1 = compteDAO.read(id1);
        Compte c2 = compteDAO.read(id2);
        c1.debit(m);
        c2.credit(m);
        c2.setNumero(null);
        compteDAO.update(c1);
        compteDAO.update(c2);

    }

}
