package com.retengr.dao.jpa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;

import com.retengr.dao.CompteDAO;
import com.retengr.model.Compte;

@Component
public class CompteDAOImpl implements CompteDAO {
	
	@PersistenceContext
	private EntityManager em;

	public void create(Compte c) {
		// TODO Auto-generated method stub
		
	}

	public void delete(Compte c) {
		// TODO Auto-generated method stub
		
	}

	public List<Compte> getCompteDuClient(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Compte read(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Compte c) {
		// TODO Auto-generated method stub
		
	}

	public void update2(Compte c) {
		// TODO Auto-generated method stub
		
	}

	

}
